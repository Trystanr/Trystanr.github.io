$('.carousel').slick({
  dots: false,
  infinite: true,
  speed: 300,
  slidesToShow: 1,
  adaptiveHeight: true, 
  autoplay: true,
  autoplaySpeed: 2000,
  draggable: false,
  fade: true
});

console.log("Hello");